# Jarvis (Voice Agent) - Android

"Jarvis" bolo, phone kaam kare: app kholna, call, SMS, call uthana/kaatna, WhatsApp auto-reply, sawal-jawab.

## Install kaise kare
1. GitHub repo -> **Releases** (right side) -> latest "Jarvis build N" -> **Jarvis.apk** download karo.
2. Phone me APK kholo -> "Install unknown apps" allow karo -> Install.
3. Jarvis app kholo:
   1. "Permissions do" -> sab Allow
   2. "Display over other apps" ON
   3. "Notification access" ON (sirf WhatsApp auto-reply ke liye)
   4. Free Gemini key: https://aistudio.google.com/apikey -> app me paste -> Save
   5. **Jarvis START**
4. Bolo: "Jarvis, WhatsApp kholo" / "Jarvis, Rahul ko call karo".

Android 13+ me agar Notification access grey ho: Settings -> Apps -> Jarvis -> (3 dots) -> **Allow restricted settings**.

## Abhi ki limitations
- Wake word "Jarvis" Google speech recognition se pakadta hai (internet chahiye, kabhi-kabhi beep aata hai).
- Call me baat karna (AI ka call ke andar bolna) abhi nahi hai. Call uthane par speaker on hota hai.
- SMS bina confirm ke turant bhej deta hai.
