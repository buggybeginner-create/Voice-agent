package com.buggybeginner.jarvis

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONObject

object Commands {

    private const val SYS = """You are Jarvis, a voice assistant running on an Android phone. The user speaks Hindi, English or Hinglish.
Convert the user's request into ONE JSON object and return ONLY that JSON, nothing else:
{"action": "...", "target": "...", "text": "...", "reply": "..."}
action must be one of:
- "open_app": open an app. target = the app name in English (e.g. "WhatsApp", "YouTube", "Camera", "Settings").
- "call": phone call. target = contact name exactly as the user said it, or a phone number.
- "sms": send an SMS. target = contact name or number, text = the message body to send.
- "answer_call": answer the ringing incoming call.
- "end_call": hang up the current call.
- "chat": anything else (questions, chit-chat). Put the answer in reply.
reply = a short spoken reply (max 2 short sentences). If the user spoke Hindi or Hinglish, reply in Hindi using Devanagari script; otherwise reply in English.
Leave unused fields as empty strings."""

    private data class Intent2(val action: String, val target: String, val text: String, val reply: String)

    /** Runs a spoken command. Returns what Jarvis should say back (can be empty). Call from a background thread. */
    fun execute(ctx: Context, utterance: String): String {
        var it2: Intent2? = null
        val raw = Gemini.generate(ctx, SYS, utterance, true)
        if (raw != null) {
            try {
                val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
                val j = JSONObject(cleaned)
                it2 = Intent2(
                    j.optString("action"), j.optString("target"),
                    j.optString("text"), j.optString("reply")
                )
            } catch (e: Exception) {
                it2 = null
            }
        }
        val cmd = it2 ?: local(utterance)

        return try {
            when (cmd.action) {
                "open_app" -> openApp(ctx, cmd.target, cmd.reply)
                "call" -> call(ctx, cmd.target)
                "sms" -> sms(ctx, cmd.target, cmd.text)
                "answer_call" -> answerCall(ctx)
                "end_call" -> endCall(ctx)
                "chat" -> cmd.reply.ifBlank { "Mujhe samajh nahi aaya." }
                else -> if (Prefs.apiKey(ctx).isBlank())
                    "Mujhe samajh nahi aaya. Behtar samajhne ke liye app me AI key daal do."
                else "Mujhe samajh nahi aaya."
            }
        } catch (e: Exception) {
            "Kuch gadbad ho gayi: ${e.message ?: "unknown error"}"
        }
    }

    // ---- Simple fallback when no AI key is set ----
    private fun local(u: String): Intent2 {
        val l = u.lowercase().trim()
        val none = Intent2("", "", "", "")
        if (listOf("answer", "receive", "utha", "uthao", "उठा").any { l.contains(it) })
            return Intent2("answer_call", "", "", "")
        if (listOf("end call", "disconnect", "cut call", "kaat", "काट").any { l.contains(it) })
            return Intent2("end_call", "", "", "")
        val smsWords = listOf("sms", "message", "msg", "मैसेज")
        val sw = smsWords.firstOrNull { l.startsWith(it) }
        if (sw != null) {
            val rest = l.removePrefix(sw).trim().split(" ", limit = 2)
            if (rest.size == 2) return Intent2("sms", rest[0], rest[1], "")
        }
        val callWords = listOf("call", "phone lagao", "कॉल", "फोन")
        if (callWords.any { l.contains(it) }) {
            var t = l
            (callWords + listOf("karo", "kar do", "lagao", "ko", "करो", "को")).forEach { t = t.replace(it, " ") }
            return Intent2("call", t.trim(), "", "")
        }
        val openWords = listOf("open", "kholo", "khol do", "khol", "खोलो", "ओपन", "chalu karo")
        if (openWords.any { l.contains(it) }) {
            var t = l
            (openWords + listOf("app", "please")).forEach { t = t.replace(it, " ") }
            return Intent2("open_app", t.trim(), "", "")
        }
        return none
    }

    private fun granted(ctx: Context, perm: String) =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    // ---- Open app ----
    private fun openApp(ctx: Context, name: String, reply: String): String {
        val q = name.lowercase().trim()
        if (q.isBlank()) return "Kaun sa app kholna hai?"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "$name naam ka app nahi mila."
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "$name khul nahi paya."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return reply.ifBlank { "${match.loadLabel(pm)} khol raha hoon." }
    }

    // ---- Contacts ----
    private fun findNumber(ctx: Context, target: String): Pair<String, String>? {
        val t = target.trim()
        if (t.isBlank()) return null
        if (t.none { it.isLetter() } && t.count { it.isDigit() } >= 7) {
            val num = t.filter { it.isDigit() || it == '+' }
            return Pair(num, num)
        }
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        val uri = Uri.withAppendedPath(
            ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI, Uri.encode(t)
        )
        ctx.contentResolver.query(
            uri,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            ),
            null, null, null
        )?.use { c ->
            if (c.moveToFirst()) return Pair(c.getString(0), c.getString(1))
        }
        return null
    }

    // ---- Call ----
    private fun call(ctx: Context, target: String): String {
        if (!granted(ctx, Manifest.permission.CALL_PHONE)) return "Call karne ki permission nahi hai."
        val (num, name) = findNumber(ctx, target) ?: return "$target naam ka contact nahi mila."
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "$name ko call laga raha hoon."
    }

    // ---- SMS ----
    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()

    private fun sms(ctx: Context, target: String, text: String): String {
        if (!granted(ctx, Manifest.permission.SEND_SMS)) return "SMS bhejne ki permission nahi hai."
        if (text.isBlank()) return "Message me kya likhna hai?"
        val (num, name) = findNumber(ctx, target) ?: return "$target naam ka contact nahi mila."
        val sm = smsManager(ctx)
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(text), null, null)
        return "$name ko message bhej diya."
    }

    // ---- Calls: answer / end ----
    @SuppressLint("MissingPermission")
    private fun answerCall(ctx: Context): String {
        if (!granted(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return "Call uthane ki permission nahi hai."
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.acceptRingingCall()
        try {
            Thread.sleep(1500)
            val am = ctx.getSystemService(AudioManager::class.java)
            am.isSpeakerphoneOn = true
        } catch (e: Exception) {
            // speaker mode is best-effort
        }
        return ""
    }

    @SuppressLint("MissingPermission")
    private fun endCall(ctx: Context): String {
        if (!granted(ctx, Manifest.permission.ANSWER_PHONE_CALLS)) return "Call kaatne ki permission nahi hai."
        val tm = ctx.getSystemService(TelecomManager::class.java)
        val ok = tm.endCall()
        return if (ok) "Call kaat diya." else "Abhi koi call chal nahi rahi."
    }
}
