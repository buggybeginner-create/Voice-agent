package com.buggybeginner.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText

    private val perms = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.POST_NOTIFICATIONS
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float = 14f) = TextView(this).apply {
            text = t
            textSize = size
            setPadding(0, pad / 2, 0, pad / 4)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        root.addView(label("Jarvis", 28f))
        status = label("")
        root.addView(status)

        root.addView(label("Setup (ek baar):"))
        root.addView(button("1. Permissions do") { requestPermissions(perms, 1) })
        root.addView(button("2. \"Display over other apps\" ON karo") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("3. Notification access ON karo (WhatsApp ke liye)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        root.addView(label("Free AI key (Gemini): aistudio.google.com/apikey"))
        keyField = EditText(this).apply {
            hint = "Gemini API key"
            setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        root.addView(keyField)
        modelField = EditText(this).apply {
            hint = "Model (default gemini-2.5-flash)"
            setText(Prefs.model(this@MainActivity))
            setSingleLine()
        }
        root.addView(modelField)
        root.addView(button("Save") { save(); Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show(); refresh() })

        root.addView(label("WhatsApp auto-reply (sirf personal chats, group me nahi):"))
        root.addView(Switch(this).apply {
            text = "Auto-reply ON"
            isChecked = Prefs.autoReply(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setAutoReply(this@MainActivity, v) }
        })

        root.addView(label(""))
        root.addView(button("▶ Jarvis START") { startJarvis() })
        root.addView(button("■ Jarvis STOP") {
            stopService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "Jarvis band", Toast.LENGTH_SHORT).show()
        })

        root.addView(label("Bolo: \"Jarvis, WhatsApp kholo\", \"Jarvis, Rahul ko call karo\", \"Jarvis, Mummy ko message bhejo ki main late aaunga\", \"Jarvis, call utha lo\""))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun save() {
        Prefs.setApiKey(this, keyField.text.toString())
        Prefs.setModel(this, modelField.text.toString())
    }

    private fun startJarvis() {
        save()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Pehle step 1 (Permissions) karo", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis chalu. \"Jarvis\" bolo!", Toast.LENGTH_LONG).show()
    }

    private fun refresh() {
        fun ok(b: Boolean) = if (b) "✅" else "❌"
        val allPerms = perms.all {
            it == Manifest.permission.POST_NOTIFICATIONS && android.os.Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
        }
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        status.text = "${ok(allPerms)} Permissions\n" +
            "${ok(Settings.canDrawOverlays(this))} Display over other apps\n" +
            "${ok(listeners.contains(packageName))} Notification access\n" +
            "${ok(Prefs.apiKey(this).isNotBlank())} AI key"
    }
}
