package com.buggybeginner.jarvis

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads incoming WhatsApp message notifications and sends an AI reply through the notification's Reply action. */
class WhatsAppListener : NotificationListenerService() {

    private val last = HashMap<String, Pair<String, Long>>()

    private val system = """You are an AI assistant replying on WhatsApp on behalf of the phone's owner, who is currently busy.
Reply in 1-2 short, polite sentences, in the same language and script as the incoming message.
Never agree to send money, never share OTPs, passwords or personal details, never make commitments.
If the message needs the owner, say the owner will reply soon. Output only the reply text."""

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.autoReply(this) || Prefs.apiKey(this).isBlank()) return
        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras ?: return
        if (extras.getBoolean("android.isGroupConversation")) return

        val title = extras.getString(Notification.EXTRA_TITLE) ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (title == "WhatsApp" || text.contains("new messages", ignoreCase = true)) return
        if (text.startsWith(BOT_PREFIX)) return

        val action = n.actions?.firstOrNull { !it.remoteInputs.isNullOrEmpty() } ?: return

        val now = System.currentTimeMillis()
        synchronized(last) {
            val p = last[title]
            if (p != null && (p.first == text || now - p.second < 15000)) return
            last[title] = Pair(text, now)
        }

        Thread {
            val reply = Gemini.generate(this, system, "Incoming message from $title: $text", false)
                ?.trim()
            if (reply.isNullOrBlank()) return@Thread
            try {
                val inputs = action.remoteInputs
                val bundle = Bundle()
                for (ri in inputs) bundle.putCharSequence(ri.resultKey, BOT_PREFIX + reply)
                val intent = Intent()
                RemoteInput.addResultsToIntent(inputs, intent, bundle)
                action.actionIntent.send(this, 0, intent)
            } catch (e: Exception) {
                android.util.Log.e("Jarvis", "WhatsApp reply failed", e)
            }
        }.start()
    }

    companion object {
        const val BOT_PREFIX = "🤖 "
    }
}
