package com.buggybeginner.jarvis

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = p(c).getString("key", "") ?: ""
    fun setApiKey(c: Context, v: String) = p(c).edit().putString("key", v.trim()).apply()

    fun model(c: Context): String = p(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setModel(c: Context, v: String) {
        val m = v.trim().ifBlank { "gemini-2.5-flash" }
        p(c).edit().putString("model", m).apply()
    }

    fun autoReply(c: Context): Boolean = p(c).getBoolean("auto", false)
    fun setAutoReply(c: Context, v: Boolean) = p(c).edit().putBoolean("auto", v).apply()
}
