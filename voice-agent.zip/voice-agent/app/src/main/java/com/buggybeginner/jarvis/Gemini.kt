package com.buggybeginner.jarvis

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Free AI backend: Google Gemini (free API key from aistudio.google.com/apikey). */
object Gemini {
    fun generate(ctx: Context, system: String, user: String, json: Boolean): String? {
        val key = Prefs.apiKey(ctx)
        if (key.isBlank()) return null
        try {
            val gen = JSONObject().put("temperature", 0.3)
            if (json) gen.put("responseMimeType", "application/json")
            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", user)))
                    )
                )
                .put("generationConfig", gen)

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${Prefs.model(ctx)}:generateContent")
            val c = url.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                Log.e("Jarvis", "Gemini error $code: $text")
                return null
            }
            return JSONObject(text)
                .getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0)
                .getString("text")
        } catch (e: Exception) {
            Log.e("Jarvis", "Gemini failed", e)
            return null
        }
    }
}
